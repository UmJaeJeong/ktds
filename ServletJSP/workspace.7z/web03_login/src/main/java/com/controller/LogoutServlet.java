package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {

 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//B역할 : 세션을 사용하는 역할
		//가. 세션얻기
		HttpSession session = request.getSession();
		
		
		//나. A에서 저장된 값 존재여부 확인
		//세션이 늘 살이있다고 생각하면안됨 늘 체크해줘야함
		String data = (String)session.getAttribute("user"); //원래라면 cart로 해야함
		String nextPage = "";
		if(data == null) {
			// 로그인 안하고 직접 CartListSerlet 요청한경우
			nextPage = "LoginFormServlet";
		}else {
			//로그인을 한 경우
			session.invalidate();
			nextPage = "main.jsp";
			
		}
		response.sendRedirect(nextPage);
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}

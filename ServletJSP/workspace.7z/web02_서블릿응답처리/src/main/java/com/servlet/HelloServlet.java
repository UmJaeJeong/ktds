package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	System.out.println("HelloServlet 호출 한번 할게용~~ ㅎㅎㅎ 삐용삐용 ");
	//요청처리 (비즈니스 로직) 
	
	//응답처리
	response.setContentType("text/html;charset=UTF-8");
	
	PrintWriter out = response.getWriter();
	out.print("<html>");
	out.print("<body>");
	out.print("hello 안뇽하떄욤!!");
	out.print("</body>");
	out.print("</html>");

	
	}

}

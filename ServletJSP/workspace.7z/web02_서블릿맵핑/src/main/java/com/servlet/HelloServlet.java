package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//http:// ip번호:포트번호 / 컨텍스트명 / 서블릿맵핑
//http://localhost:8090/app2/HelloServlet
//서블릿 맵핑하는 방법중 첫번째 방법은 어노테이션을 이용하는 방법이다.
@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("HelloServlet >>");
	}

}

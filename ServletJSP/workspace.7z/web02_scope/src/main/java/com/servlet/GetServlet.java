package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/get")
public class GetServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//1.request Scope 형변환을 해야한다 		==>  요청(생성) ~ 응답(소멸)
		String s = (String)request.getAttribute("request"); //있으면 request라는 글자의 응답처리
		
		//2. session Scope( HttpSession ) ==> 나중에 심화강의, 브라우저 시작 ~ 브라우저 종료
		HttpSession session = request.getSession();
		String s2 = (String)session.getAttribute("session");
		
		//3. application Scope
		ServletContext application = getServletContext();
		String s3 = (String)application.getAttribute("application");
		
		//포워드
		//RequestDispatcher dis =  request.getRequestDispatcher("get");
		//dis.forward(request, response);
		
		//응답처리
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<body>");
		out.print("request scope 나와랏! 뿅!! : "+ s+"     ");
		out.print("session scope 나와랏! 뿅!! : "+ s2+"     ");
		out.print("application scope 나와랏! 뿅!! : "+ s3+"     ");

		out.print("</body>");
		out.print("</html>");

	}

}

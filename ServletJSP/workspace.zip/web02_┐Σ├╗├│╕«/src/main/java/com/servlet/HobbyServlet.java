package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/yyy")
public class HobbyServlet extends HttpServlet {

	// GET은 URL에 전달하고자하는 정보가 보임
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//checkbox에서 선택된 값을 얻기
		//getParameter로 가져올 경우 같은 name이 많을때 마지막 name을 가진 값을 가져온다.
		String[] hobbies = request.getParameterValues("hobby");//값이 여러개일 경우 getParameterValues를 사용
		System.out.println(Arrays.toString(hobbies));
		
		//Method는 생략하면 2개의 값을 받는다.

	}

}

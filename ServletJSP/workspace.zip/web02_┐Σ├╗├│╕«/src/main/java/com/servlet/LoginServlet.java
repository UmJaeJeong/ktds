package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/xxx")
public class LoginServlet extends HttpServlet {

	// GET은 URL에 전달하고자하는 정보가 보임
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("LoginServlet : GET");
		// LoginForm jsp를 직접 구현해서 로그인 버튼 누르기

		// 사용자 입력 데이터 얻기
		String id = request.getParameter("userid");
		String pw = request.getParameter("userpw");

		// 응답처리
		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<body>");
		out.print("ID : " + id + "<br>");
		out.print("PW : " + pw);
		out.print("</body>");
		out.print("</html>");

	}

	// POST은 URL에 전달하고자하는 정보가 안보임 숨김
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("LoginServlet : POST");
		// LoginForm jsp를 직접 구현해서 로그인 버튼 누르기

		// 사용자 입력 데이터 얻기
		// Post는 한글처리 필수
		String id = request.getParameter("userid");
		String pw = request.getParameter("userpw");

		// 응답처리
		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<body>");
		out.print("ID : " + id + "<br>");
		out.print("PW : " + pw);
		out.print("</body>");
		out.print("</html>");

	}

}

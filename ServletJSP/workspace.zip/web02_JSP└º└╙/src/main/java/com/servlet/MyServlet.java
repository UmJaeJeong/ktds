package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/xxx")
public class MyServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("MyServlet");
		
		//리다이렉트(redirect) //변경이된다. hello.jsp로 Url이 변경됨
		response.sendRedirect("hello.jsp"); //JSP에 바로 접근 가능하지만 늘 서블릿을 통해 접근
	}

}

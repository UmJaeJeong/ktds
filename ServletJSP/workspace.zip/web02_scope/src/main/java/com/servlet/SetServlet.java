package com.servlet;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/set")
public class SetServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//scope에 데이터 저장 (기본형 및 참조형 가능) 데이터 3가지 저장소 저장방법 
		//1. request scope ( HttpServletRequest) // 요청 ~ 응답까지 살아있음
		request.setAttribute("request", "request"); //request를 확장시킬수 있는것은 Foward
		
		//2. session scope (HttpSession)  //브라우저 종료시 없어짐 ex) 로그인, 장바구니
		HttpSession session = request.getSession();
		session.setAttribute("session", "session");
		
		//3.application scope ( ServletContext ) 
		ServletContext application = getServletContext();
		application.setAttribute("application", "application");
	}

}

package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//http:// ip번호:포트번호 / 컨텍스트명 / 서블릿맵핑
//http://localhost:8090/app2/LifeCycleServlet
//서블릿 맵핑하는 방법중 첫번째 방법은 어노테이션을 이용하는 방법이다.
public class LifeCycleServlet extends HttpServlet {
	
	int num = 0; //인스턴스변수임에도 불구하고 누적될수 있다.(공유가능) : 위험하다. 안돼요~~ 위험해요~
	List<String> list = new ArrayList<>();
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("생성자 뿅~~!!!");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		num++;
		list.add("hello");
		System.out.println("HelloServlet >> "+num + "\t"+list);
	}

	
	

}

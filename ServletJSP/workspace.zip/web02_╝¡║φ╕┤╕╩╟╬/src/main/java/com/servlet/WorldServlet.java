package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//http:// ip번호:포트번호 / 컨텍스트명 / 서블릿맵핑
//http://localhost:8090/app2/HelloServlet
//서블릿 맵핑하는 방법중  두번째 방법은 web.XML 사용법이다.
public class WorldServlet extends HttpServlet {
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("WorldHello");
	}

}

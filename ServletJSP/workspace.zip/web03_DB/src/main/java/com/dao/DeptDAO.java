package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dto.DeptDTO;

//DAO : Data Access Object
//DB 전담 클래스, 일반적으로 테이블 당 한개씨 지정함.
public class DeptDAO {
	
	//나머지 작업들 sql+ preparedStatement + ResultSet
	public List<DeptDTO> select(Connection con) {
		List<DeptDTO> list = new ArrayList<>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select deptno as no, dname as name, loc from dept";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int deptno = rs.getInt("no");
				String dname = rs.getString("name");
				String loc = rs.getString(3);
				System.out.println(deptno+"\t"+dname+"\t"+loc);
				
				DeptDTO dto = new DeptDTO(deptno, dname, loc);
				list.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null ) pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return list;

	}

}

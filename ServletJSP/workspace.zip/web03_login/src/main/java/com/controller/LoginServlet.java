package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//A 역할:세션을 생성하는 역할
		//사용자가 입력한 값 얻기
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
//		System.out.println(userid);
//		System.out.println(passwd);
		
		//id와 pw이용해서 DB연동해서 존재여부 확인
		
		//DB에서 가져온 사용자 데이터를 세션에 저장
		//다른 페이지에서 사용자 정보를 조회하는 기능
		//가. 빨간박스 얻기
		//request.getSession(); // 빨간박스 있으면 재사용, 없으면 새로 생성
		HttpSession session = request.getSession();
		
		//나. 데이터 저장
		session.setAttribute("user", userid);
		
		//다. 로그인 이후 화면 처리
		response.sendRedirect("info.jsp");
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}
